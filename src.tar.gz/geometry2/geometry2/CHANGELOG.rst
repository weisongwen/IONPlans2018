^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package geometry2
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.5.16 (2017-07-14)
-------------------

0.5.15 (2017-01-24)
-------------------

0.5.14 (2017-01-16)
-------------------
* create geometry2 metapackage and make geometry_experimental depend on it for clarity of reverse dependency walking.
* Contributors: Tully Foote
